﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication.Models;

namespace WebApplication.Controllers
{
    public class RegisterController : Controller
    {
        AhmadRazaEntities1 db = new AhmadRazaEntities1();
        // GET: /Register/
        public ActionResult SetDataInDatabase()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SetDataInDatabase(LoginPanel model)
        {
            LoginPanel tb1 = new LoginPanel();
            tb1.Username = model.Username;
           
            if (int.Parse(model.Password) >10)
            {
                tb1.Password = "invalid marks";
               
            }
            else
            {
                tb1.Password = model.Password;
              
            }
            db.LoginPanels.Add(tb1);
            db.SaveChanges();
            return View();
        }
        public ActionResult showDataBaseForUser()
        {

            var item = db.LoginPanels.ToList();
            return View(item);
        }
        public ActionResult Delete(int id)
        {
            var item= db.LoginPanels.Where(x => x.ID == id).First();
            db.LoginPanels.Remove(item);
            db.SaveChanges();
            var item2 = db.LoginPanels.ToList();
            return View("showDataBaseForUser", item2);

        }
        public ActionResult Edit(int id)
        {
            var item = db.LoginPanels.Where(x => x.ID == id).First();
            return View(item);
        }
        [HttpPost]
        public ActionResult Edit(LoginPanel model)
        {
            var item = db.LoginPanels.Where(x => x.ID == model.ID).First();
            item.Username = model.Username;
            if (int.Parse(model.Password) > 10)
            {
                item.Password = "invalid marks";

            }
            else
            {
                item.Password = model.Password;
            }
            db.SaveChanges();
            return View();
        }
	}
}